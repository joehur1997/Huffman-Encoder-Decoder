Joseph Hur
jhur3@u.rochester.edu
Class ID: 67
Project 3

Followed instructions for submitting the project, and hopefully there are no issues with program and the auto-grade procedure.